var _BoxDecation = /** @class */ (function () {
    function _BoxDecation(args) {
        var _a;
        this.color = (_a = args.color) === null || _a === void 0 ? void 0 : _a.value;
    }
    return _BoxDecation;
}());
function BoxDecation(args) {
    return new _BoxDecation(args);
}
export { BoxDecation, _BoxDecation };
//# sourceMappingURL=BoxDecoration.js.map