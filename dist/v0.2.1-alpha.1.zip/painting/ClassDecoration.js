var ClassDecoration = /** @class */ (function () {
    function ClassDecoration() {
    }
    return ClassDecoration;
}());
export { ClassDecoration };
//# sourceMappingURL=ClassDecoration.js.map