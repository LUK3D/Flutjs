import { TextTheme } from "../material/text_theme.js";
declare class Typography {
    constructor();
    blackMountainView: TextTheme;
}
export { Typography };
