declare class ClassDecoration {
    background?: string;
    border?: string;
    color?: string;
    display?: string;
    flex?: string;
}
export { ClassDecoration };
