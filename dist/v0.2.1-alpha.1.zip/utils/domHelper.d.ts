declare function AddAttr(el: HTMLElement, args: {
    property: string;
    value: string;
}): HTMLElement;
export { AddAttr };
