declare function WidgetExeption(args: {
    message?: string;
}): void;
declare function ConversioException(args: {
    message?: string;
}): void;
export { WidgetExeption, ConversioException };
