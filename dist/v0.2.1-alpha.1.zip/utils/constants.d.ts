declare var Mesurements: string[];
declare var ElementSides: string[];
export { Mesurements, ElementSides };
