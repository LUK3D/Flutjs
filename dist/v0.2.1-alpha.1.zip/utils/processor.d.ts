import { Widget } from "../widgets/index.js";
declare function ExtractCss(widget: Widget): string;
export { ExtractCss };
