var Mesurements = [
    'px', 'vh', 'vw', '%', 'pt',
];
var ElementSides = [
    "left",
    "top",
    "right",
    "bottom",
];
export { Mesurements, ElementSides };
//# sourceMappingURL=constants.js.map