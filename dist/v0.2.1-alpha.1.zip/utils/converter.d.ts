declare class Converter {
    val?: string | number;
    constructor();
    toNumber(val?: string | number): number;
}
export { Converter };
