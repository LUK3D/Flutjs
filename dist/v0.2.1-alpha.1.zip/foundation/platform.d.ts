declare enum TargetPlatform {
    android = 0,
    fuchsia = 1,
    iOS = 2,
    linux = 3,
    macOS = 4,
    windows = 5
}
export { TargetPlatform };
