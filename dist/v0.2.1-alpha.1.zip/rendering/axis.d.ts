declare enum Axis {
    Horizontal = 0,
    Vertical = 1
}
export { Axis };
