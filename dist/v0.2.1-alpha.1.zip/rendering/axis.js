var Axis;
(function (Axis) {
    Axis[Axis["Horizontal"] = 0] = "Horizontal";
    Axis[Axis["Vertical"] = 1] = "Vertical";
})(Axis || (Axis = {}));
export { Axis };
//# sourceMappingURL=axis.js.map